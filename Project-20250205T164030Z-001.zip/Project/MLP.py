import numpy as np

class MLP:
    def __init__(self, n_inputs, n_hidden1, n_hidden2, n_outputs, activation='sigmoid'):
        # Initialize the weights and biases of the MLP
        np.random.seed(42)
        self.weights1 = np.random.randn(n_inputs, n_hidden1)
        self.biases1 = np.zeros(n_hidden1)
        self.weights2 = np.random.randn(n_hidden1, n_hidden2)
        self.biases2 = np.zeros(n_hidden2)
        self.weights3 = np.random.randn(n_hidden2, n_outputs)
        self.biases3 = np.zeros(n_outputs)
        
        # Set the activation function
        if activation == 'sigmoid':
            self.activation = self.sigmoid
            self.d_activation = self.d_sigmoid
        elif activation == 'relu':
            self.activation = self.relu
            self.d_activation = self.d_relu
        else:
            raise ValueError(f'Invalid activation function: {activation}')

    def sigmoid(self, z):
        
        return 1 / (1 + np.exp(-z))

    def d_sigmoid(self, z):
        return self.sigmoid(z) * (1 - self.sigmoid(z))
    
    def relu(self, z):
        return np.maximum(0, z)

    def d_relu(self, z):
        return (z > 0).astype(float)

    def mse_loss(self, y_true, y_pred):
        y_pred = y_pred.reshape(y_true.shape)
        return np.mean((y_true - y_pred) ** 2)

    def d_mse_loss(self, y_true, y_pred):
        return 2 * (y_pred - y_true.reshape(-1, 1)) / len(y_true)

    def forward_pass(self, X):
        # Compute the predictions of the MLP on the input data
        z1 = X.dot(self.weights1) + self.biases1
        a1 = self.activation(z1)
        z2 = a1.dot(self.weights2) + self.biases2
        a2 = self.activation(z2)
        z3 = a2.dot(self.weights3) + self.biases3
        y_pred = z3
        return y_pred, z1, a1, z2, a2

    def backward_pass(self, X, y_true, y_pred, z1, a1, z2, a2):
        # Compute the gradients of the loss with respect to the weights and biases of the MLP
        d_z3 = self.d_mse_loss(y_true, y_pred)
        d_a2 = d_z3.dot(self.weights3.T)
        d_z2 = d_a2 * self.d_activation(z2)
        d_weights2 = a1.T.dot(d_z2)
        d_biases2 = d_z2.sum(axis=0)
        d_a1 = d_z2.dot(self.weights2.T)
        d_z1 = d_a1 * self.d_activation(z1)
        d_weights1 = X.T.dot(d_z1)
        d_biases1 = d_z1.sum(axis=0)
        d_weights3 = a2.T.dot(d_z3)
        d_biases3 = d_z3.sum(axis=0)
        return d_z3, d_weights1, d_biases1, d_weights2, d_biases2, d_weights3, d_biases3
    
    def update_weights_biases(self, learning_rate,d_weights1, d_biases1, d_weights2, d_biases2, d_weights3, d_biases3):
        # Update the weights and biases of the MLP using gradient descent
        self.weights3 =self.weights3 - learning_rate * d_weights3
        self.biases3 =self.biases3 - learning_rate * d_biases3
        self.weights2 = self.weights2 - learning_rate * d_weights2
        self.biases2 = self.biases2 - learning_rate * d_biases2
        self.weights1 =self.weights1 - learning_rate * d_weights1
        self.biases1 =self.biases1 - learning_rate * d_biases1
        
    def fit(self, X_train, y_train, learning_rate=0.01, n_epochs=1000):
        # Train the MLP for a fixed number of epochs
        for epoch in range(n_epochs):
            # Forward pass: compute the predictions of the MLP on the training set
            y_pred, z1, a1, z2, a2 = self.forward_pass(X_train)

            # Compute the training loss
            loss = self.mse_loss(y_train, y_pred)
            # Backward pass: compute the gradients and update the weights and biases of the MLP
            d_z3, d_weights1, d_biases1, d_weights2, d_biases2, d_weights3, d_biases3 = self.backward_pass(X_train, y_train, y_pred, z1, a1, z2, a2)
            if epoch % 50 ==0:
              print(f'epochs = {epoch} ============> loss {loss} ')
            self.update_weights_biases(learning_rate, d_weights1, d_biases1, d_weights2, d_biases2, d_weights3, d_biases3)

    def predict(self, X_test):
        # Compute and return the predictions of the MLP on the test set
        y_pred_test, z1, a1, z2, a2 = self.forward_pass(X_test)
        return y_pred_test
